import React from 'react'

const Footer = () => {
    return (
        <footer className='text-center'>Fruit King ©2022 Created by Najmus Sakib</footer>
    )
}

export default Footer